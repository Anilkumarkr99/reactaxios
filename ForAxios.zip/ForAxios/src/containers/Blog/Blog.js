import React, { Component } from 'react';

import Post from '../../components/Post/Post';
import FullPost from '../../components/FullPost/FullPost';
import NewPost from '../../components/NewPost/NewPost';
import './Blog.css';

import axios from 'axios'

class Blog extends Component {
    state = {
        postContent: [],
        loading: false
    }
    componentDidMount() {
        axios.get("http://jsonplaceholder.typicode.com/posts").then((data) => {
            console.log(data.data)
            this.setState({
                postContent: data.data.slice(0,6),
                loading: !this.state.loading
            });

        })
    }
    render() {
        console.log(this.state.postContent.data)
        return (
            <div>
                <section className="Posts">
                    {
                        this.state.postContent.map((data) => <Post title={data.title} id={data.id}/>)
                }
                </section>
                <section>
                    <FullPost />
                </section>
                <section>
                    <NewPost />
                </section>
            </div>
        );
    }
}

export default Blog;