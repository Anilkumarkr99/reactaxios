const redux = require('redux')
const createStore = redux.createStore

const initialState = {
    counter: 0
}
const reducer = (state = initialState, action) => {
    if (action.type == '[Counter] INC') {
        return {
            counter: state.counter += 1
        }
    }
    if (action.type == '[Counter] DEC') {
        return {
            counter: state.counter -= 1
        }
    }
    return state
}
const store = createStore(reducer)
store.subscribe(() => {
    console.log('new state is', store.getState())
})
console.log('state of store', store.getState())

store.dispatch({ type: '[Counter] INC' })
console.log('state of store', store.getState())